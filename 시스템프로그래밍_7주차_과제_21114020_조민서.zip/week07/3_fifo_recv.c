/*
 * 3_fifo_recv.c — FIFO 로 메시지를 받는 쪽  [먼저 실행]
 *
 * [동작]
 *   ./3_fifo_recv        보내는 쪽 하나가 연결을 끊으면(EOF) FIFO 를 지우고 끝낸다 (기본 과제)
 *   ./3_fifo_recv -l     EOF 가 와도 끝내지 않고 FIFO 를 다시 open 해 다음 보내는 쪽을 기다린다
 *                        (도전 과제: 여러 클라이언트를 받는 FIFO 서버)
 *                        "quit" 메시지를 받거나 Ctrl+C 를 누르면 끝낸다.
 *
 * [메시지 규약]
 *   파이프는 경계가 없는 바이트 스트림이므로, 메시지 하나 = 줄('\n') 하나로 약속한다.
 *   보내는 쪽은 한 줄을 PIPE_BUF(4096) 이하로 한 번에 write 하므로
 *   여러 클라이언트가 동시에 써도 줄이 섞이지 않는다.
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 3_fifo_recv 3_fifo_recv.c
 *   ./3_fifo_recv            (터미널 A)
 *   ./4_fifo_send 안녕       (터미널 B)
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#define FIFO_PATH "/tmp/sysprog_fifo"
#define BUF_SIZE  8192

static volatile sig_atomic_t stop = 0;

static void on_signal(int sig)
{
    (void)sig;
    stop = 1;   /* 핸들러에서는 플래그만 세우고, 정리는 main 에서 한다 */
}

/* buf 안의 완성된 줄들을 출력하고, 남은(아직 '\n' 이 안 온) 조각을 앞으로 당긴다.
   "quit" 줄을 만나면 1 을 돌려준다. */
static int handle_lines(char *buf, size_t *len, int client)
{
    int quit = 0;
    char *start = buf, *nl;
    while ((nl = memchr(start, '\n', (size_t)(buf + *len - start))) != NULL) {
        *nl = '\0';
        printf("  [클라이언트 #%d] 받은 메시지: %s\n", client, start);
        if (strcmp(start, "quit") == 0) quit = 1;
        start = nl + 1;
    }
    *len = (size_t)(buf + *len - start);
    memmove(buf, start, *len);
    return quit;
}

int main(int argc, char *argv[])
{
    int loop = (argc == 2 && strcmp(argv[1], "-l") == 0);
    if (argc > 2 || (argc == 2 && !loop)) {
        fprintf(stderr, "사용법: %s [-l]\n", argv[0]);
        return 1;
    }

    /* SA_RESTART 를 주지 않아야 open/read 에서 막혀 있다가 Ctrl+C 로 깨어난다(EINTR) */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGINT, &sa, NULL) == -1 || sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("sigaction");
        return 1;
    }

    /* FIFO 를 만든다. 이미 있으면(EEXIST) 그대로 쓴다. */
    if (mkfifo(FIFO_PATH, 0666) == -1 && errno != EEXIST) {
        perror("mkfifo");
        return 1;
    }
    printf("FIFO 준비: %s (%s 모드)\n", FIFO_PATH, loop ? "여러 클라이언트" : "한 번");

    int ret = 0, client = 0, quit = 0;
    while (!stop && !quit) {
        printf("보내는 쪽을 기다립니다...\n");
        fflush(stdout);

        int fd = open(FIFO_PATH, O_RDONLY);   /* 쓰는 쪽이 열 때까지 여기서 블록 */
        if (fd == -1) {
            if (errno == EINTR) break;        /* Ctrl+C */
            perror("open");
            ret = 1;
            break;
        }
        client++;
        printf("[클라이언트 #%d] 연결됨\n", client);

        char buf[BUF_SIZE];
        size_t len = 0;
        ssize_t n;
        while ((n = read(fd, buf + len, sizeof buf - 1 - len)) > 0) {
            len += (size_t)n;
            if (handle_lines(buf, &len, client)) quit = 1;
            if (len == sizeof buf - 1) {      /* '\n' 없이 버퍼가 꽉 찼다 → 그대로 출력 */
                buf[len] = '\0';
                printf("  [클라이언트 #%d] 받은 메시지(잘림): %s\n", client, buf);
                len = 0;
            }
        }
        if (n == -1 && errno != EINTR) { perror("read"); ret = 1; }
        if (len > 0) {                        /* 마지막 줄에 '\n' 이 없었던 경우 */
            buf[len] = '\0';
            printf("  [클라이언트 #%d] 받은 메시지: %s\n", client, buf);
        }
        fflush(stdout);

        /* n == 0 : 쓰는 쪽 fd 가 모두 닫혔다 = EOF */
        if (close(fd) == -1) { perror("close"); ret = 1; }
        if (n == 0) printf("[클라이언트 #%d] 연결 종료(EOF)\n", client);

        if (!loop || ret) break;              /* 기본 모드는 한 번만 받고 끝 */
    }

    if (stop)  printf("\n시그널을 받아 종료합니다.\n");
    if (quit)  printf("quit 메시지를 받아 종료합니다.\n");

    /* 다 썼으면 FIFO 파일을 지운다 — 안 지우면 /tmp 에 계속 남는다 */
    if (unlink(FIFO_PATH) == -1) {
        perror("unlink");
        ret = 1;
    } else {
        printf("FIFO 삭제 완료: %s\n", FIFO_PATH);
    }
    return ret;
}
