/*
 * 4_fifo_send.c — FIFO 로 메시지를 보내는 쪽  [나중에 실행]
 *
 * [동작]
 *   ./4_fifo_send 안녕 "두 번째 메시지"   인자 하나하나를 메시지 한 줄로 보낸다
 *   ./4_fifo_send                         표준입력에서 한 줄씩 읽어 보낸다 (Ctrl+D 로 끝)
 *   ./4_fifo_send quit                    받는 쪽(-l 모드)을 종료시킨다
 *
 *   받는 쪽과 부모-자식 관계가 아니어도 FIFO 의 "이름"만 알면 통신할 수 있다.
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 4_fifo_send 4_fifo_send.c
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <limits.h>     /* PIPE_BUF */
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#define FIFO_PATH "/tmp/sysprog_fifo"

/* 메시지 한 줄을 '\n' 까지 붙여 "한 번의 write" 로 보낸다.
   PIPE_BUF 이하이면 원자적이라 다른 클라이언트의 메시지와 섞이지 않는다. */
static int send_line(int fd, const char *msg)
{
    char line[PIPE_BUF];
    size_t len = strlen(msg);
    if (len + 1 > sizeof line) {
        fprintf(stderr, "메시지가 너무 깁니다(최대 %zu바이트): 건너뜀\n", sizeof line - 1);
        return 0;
    }
    memcpy(line, msg, len);
    line[len++] = '\n';

    ssize_t n;
    do {
        n = write(fd, line, len);
    } while (n == -1 && errno == EINTR);

    if (n == -1) {
        if (errno == EPIPE) fprintf(stderr, "받는 쪽이 사라졌습니다 (EPIPE)\n");
        else perror("write");
        return -1;
    }
    printf("보냈습니다: %s\n", msg);
    return 0;
}

int main(int argc, char *argv[])
{
    /* 받는 쪽이 중간에 끝나도 SIGPIPE 로 조용히 죽지 않고 EPIPE 로 알아차리게 한다 */
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR) { perror("signal"); return 1; }

    /* FIFO 가 실제로 있는지, 정말 FIFO 인지 먼저 확인 */
    struct stat st;
    if (stat(FIFO_PATH, &st) == -1) {
        perror("stat (받는 쪽 3_fifo_recv 를 먼저 실행했는지 확인)");
        return 1;
    }
    if (!S_ISFIFO(st.st_mode)) {
        fprintf(stderr, "%s 는 FIFO 가 아닙니다\n", FIFO_PATH);
        return 1;
    }

    int fd = open(FIFO_PATH, O_WRONLY);   /* 읽는 쪽이 열려 있지 않으면 여기서 블록 */
    if (fd == -1) {
        perror("open");
        return 1;
    }

    int ret = 0;
    if (argc >= 2) {
        for (int i = 1; i < argc && ret == 0; i++)
            if (send_line(fd, argv[i]) == -1) ret = 1;
    } else {
        char line[PIPE_BUF];
        if (isatty(STDIN_FILENO))
            printf("보낼 메시지를 입력하세요 (끝내려면 Ctrl+D)\n");
        while (ret == 0 && fgets(line, sizeof line, stdin) != NULL) {
            line[strcspn(line, "\n")] = '\0';
            if (send_line(fd, line) == -1) ret = 1;
        }
        if (ferror(stdin)) { perror("fgets"); ret = 1; }
    }

    /* 닫아야 받는 쪽 read 가 0(EOF)을 본다 */
    if (close(fd) == -1) { perror("close"); ret = 1; }
    return ret;
}
