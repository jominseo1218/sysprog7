/*
 * 1_pipe.c — 파이프 두 개로 부모 ↔ 자식 문자열 왕복
 *
 * [동작]
 *   부모가 문자열을 p2c(parent→child) 파이프로 보내면,
 *   자식이 대문자로 바꿔 c2p(child→parent) 파이프로 돌려준다.
 *
 * [fd 정리표] — 파이프 2개 = fd 4개, 각 프로세스가 2개씩 닫는다
 *            p2c[0](읽기)  p2c[1](쓰기)  c2p[0](읽기)  c2p[1](쓰기)
 *   부모        close         사용          사용          close
 *   자식        사용          close         close         사용
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 1_pipe 1_pipe.c
 *   ./1_pipe "hello world"
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUF_SIZE 4096

/* write 는 요청한 것보다 적게 쓸 수 있으므로 끝까지 반복해서 쓴다 */
static int write_all(int fd, const char *buf, size_t len)
{
    while (len > 0) {
        ssize_t n = write(fd, buf, len);
        if (n == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        buf += n;
        len -= (size_t)n;
    }
    return 0;
}

/* 자식: p2c 에서 EOF 가 올 때까지 읽어 대문자로 바꿔 c2p 로 돌려준다 */
static void child_work(int in_fd, int out_fd)
{
    char buf[BUF_SIZE];
    ssize_t n;

    while ((n = read(in_fd, buf, sizeof buf)) > 0) {
        for (ssize_t i = 0; i < n; i++)
            buf[i] = (char)toupper((unsigned char)buf[i]);  /* 한글(UTF-8 다바이트)은 그대로 */
        if (write_all(out_fd, buf, (size_t)n) == -1) {
            perror("[자식] write");
            _exit(1);
        }
    }
    if (n == -1) {
        perror("[자식] read");
        _exit(1);
    }
    /* n == 0 : 부모가 p2c 쓰기 끝을 닫았다 → EOF */
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "사용법: %s \"보낼 문자열\"\n", argv[0]);
        return 1;
    }
    const char *msg = argv[1];

    int p2c[2], c2p[2];
    if (pipe(p2c) == -1) { perror("pipe p2c"); return 1; }
    if (pipe(c2p) == -1) { perror("pipe c2p"); return 1; }

    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {
        /* ── 자식: p2c 로 읽고 c2p 로 쓴다 ── */
        if (close(p2c[1]) == -1 || close(c2p[0]) == -1) {
            perror("[자식] close");
            _exit(1);
        }
        child_work(p2c[0], c2p[1]);
        close(p2c[0]);
        close(c2p[1]);   /* 닫아야 부모의 read 가 EOF(0)를 본다 */
        _exit(0);
    }

    /* ── 부모: p2c 로 쓰고 c2p 로 읽는다 ── */
    if (close(p2c[0]) == -1 || close(c2p[1]) == -1) {
        perror("[부모] close");
        return 1;
    }

    printf("[부모] 보냄  : \"%s\"\n", msg);
    fflush(stdout);
    if (write_all(p2c[1], msg, strlen(msg)) == -1) {
        perror("[부모] write");
        return 1;
    }
    /* 다 보냈으면 쓰기 끝을 닫는다 — 이걸 안 하면 자식이 EOF 를 못 봐서
       영원히 read 에서 멈추고, 그러면 부모도 c2p 에서 영원히 기다린다(교착). */
#ifndef BUG_NO_CLOSE   /* make bug 로 이 close 를 빼고 빌드하면 교착이 재현된다 */
    if (close(p2c[1]) == -1) { perror("[부모] close p2c[1]"); return 1; }
#else
    printf("[부모] (실험) p2c[1] 을 닫지 않음 → 자식이 EOF 를 못 봄\n");
    fflush(stdout);
#endif

    /* 결과를 EOF 까지 모아서 받는다(한 번의 read 로 다 온다는 보장이 없다) */
    size_t cap = strlen(msg) + 1, len = 0;
    char *reply = malloc(cap);
    if (reply == NULL) { perror("malloc"); return 1; }

    ssize_t n;
    while ((n = read(c2p[0], reply + len, cap - 1 - len)) > 0) {
        len += (size_t)n;
        if (len == cap - 1) {                 /* 공간이 모자라면 늘린다 */
            char *tmp = realloc(reply, cap * 2);
            if (tmp == NULL) { perror("realloc"); free(reply); return 1; }
            reply = tmp;
            cap *= 2;
        }
    }
    if (n == -1) { perror("[부모] read"); free(reply); return 1; }
    reply[len] = '\0';
    close(c2p[0]);

    int status;
    if (waitpid(pid, &status, 0) == -1) { perror("waitpid"); free(reply); return 1; }

    printf("[부모] 돌려받음: \"%s\"\n", reply);
    printf("[부모] 자식(pid %d) 종료 코드 %d\n", (int)pid,
           WIFEXITED(status) ? WEXITSTATUS(status) : -1);

    free(reply);
    return 0;
}
