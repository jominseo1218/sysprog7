/*
 * 2_pipeline.c — dup2 로 두 명령을 파이프로 이어 붙인다 (셸의 "A | B")
 *
 * [동작]
 *   ./2_pipeline ls -l : wc -l      ==  셸의  ls -l | wc -l
 *   ':' 를 기준으로 앞 명령과 뒤 명령을 나눈다.
 *
 * [핵심]
 *   자식 A : dup2(fd[1], STDOUT_FILENO) → 앞 명령의 표준출력이 파이프로
 *   자식 B : dup2(fd[0], STDIN_FILENO)  → 뒤 명령의 표준입력이 파이프에서
 *   부모   : fd[0], fd[1] 둘 다 닫는다 → 그래야 B 가 EOF 를 보고 끝난다
 *
 * [컴파일·실행]
 *   gcc -Wall -Wextra -o 2_pipeline 2_pipeline.c
 *   ./2_pipeline ls -l : wc -l
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static void usage(const char *prog)
{
    fprintf(stderr, "사용법: %s 명령1 [인자...] : 명령2 [인자...]\n", prog);
    fprintf(stderr, "  예)   %s ls -l : wc -l\n", prog);
}

int main(int argc, char *argv[])
{
    /* ':' 위치 찾기 — argv 를 그 자리에서 NULL 로 잘라 두 개의 인자 배열로 쓴다 */
    int sep = -1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], ":") == 0) { sep = i; break; }
    }
    if (sep == -1 || sep == 1 || sep == argc - 1) {   /* ':' 없음 / 앞·뒤 명령이 비었음 */
        usage(argv[0]);
        return 1;
    }
    argv[sep] = NULL;
    char **cmd1 = &argv[1];        /* 예: {"ls", "-l", NULL}  */
    char **cmd2 = &argv[sep + 1];  /* 예: {"wc", "-l", NULL}  (argv[argc] 는 원래 NULL) */

    int fd[2];   /* fd[0] = 읽기 끝, fd[1] = 쓰기 끝 */
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    /* ── 자식 A : 앞 명령, 표준출력 → 파이프 쓰기 끝 ── */
    pid_t pa = fork();
    if (pa == -1) { perror("fork"); return 1; }
    if (pa == 0) {
        if (close(fd[0]) == -1) { perror("close"); _exit(126); }
        if (dup2(fd[1], STDOUT_FILENO) == -1) { perror("dup2 stdout"); _exit(126); }
        if (close(fd[1]) == -1) { perror("close"); _exit(126); }   /* 복사본이 fd 1 에 있으므로 원본은 닫는다 */
        execvp(cmd1[0], cmd1);
        perror(cmd1[0]);           /* exec 가 실패했을 때만 도달 */
        _exit(127);
    }

    /* ── 자식 B : 뒤 명령, 표준입력 ← 파이프 읽기 끝 ── */
    pid_t pb = fork();
    if (pb == -1) { perror("fork"); return 1; }
    if (pb == 0) {
        if (close(fd[1]) == -1) { perror("close"); _exit(126); }   /* 이걸 안 닫으면 B 자신이 쓰기 끝을 들고 있어 EOF 가 영원히 안 온다 */
        if (dup2(fd[0], STDIN_FILENO) == -1) { perror("dup2 stdin"); _exit(126); }
        if (close(fd[0]) == -1) { perror("close"); _exit(126); }
        execvp(cmd2[0], cmd2);
        perror(cmd2[0]);
        _exit(127);
    }

    /* ── 부모 : 양쪽 다 닫는다 ── */
    if (close(fd[0]) == -1 || close(fd[1]) == -1) { perror("close"); return 1; }

    /* 두 자식을 모두 거둔다. 셸처럼 파이프라인의 종료 코드는 마지막 명령의 것으로 한다. */
    int status, result = 0;
    for (int done = 0; done < 2; done++) {
        pid_t w = wait(&status);
        if (w == -1) { perror("wait"); return 1; }
        if (w == pb)
            result = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    }
    return result;
}
